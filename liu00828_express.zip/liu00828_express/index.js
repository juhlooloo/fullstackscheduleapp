// YOU CAN USE THIS FILE AS REFERENCE FOR SERVER DEVELOPMENT

// include the express module
var express = require("express");

// create an express application
var app = express();
const url = require('url');

// helps in extracting the body portion of an incoming request stream
var bodyparser = require('body-parser');

// fs module - provides an API for interacting with the file system
var fs = require("fs");

// helps in managing user sessions
var session = require('express-session');

// include the mysql module
var mysql = require("mysql");

// helpful for reading, compiling, rendering pug templates
const pug = require("pug");  

// Bcrypt library for comparing password hashes
const bcrypt = require('bcrypt');
const path = require('path');

app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'pug');
// A  library that can help read uploaded file for bonus.
// var formidable = require('formidable')


// apply the body-parser middleware to all incoming requests
app.use(bodyparser.json());
app.use(bodyparser.urlencoded({extended: false}));
// use express-session
// in mremory session is sufficient for this assignment
app.use(session({
  secret: "csci4131secretkey",
  saveUninitialized: true,
  resave: false
}
));

var connection = mysql.createConnection({
  host: "cse-mysql-classes-01.cse.umn.edu",
  user: "C4131DF23U57",               // replace with the database user provided to you
  password: "3299",                  // replace with the database password provided to you
  database: "C4131DF23U57",           // replace with the database user provided to you
  port: 3306
});
connection.connect(function(err){
  if(err){
    throw err;
  }console.log("Conencted to database!");
});


// server listens on port 9007 for incoming connections
app.listen(9007, () => console.log('Listening on port 9007!'));


// function to return the welcome page
app.get('/',function(req, res) {
  res.render('welcome');
});

app.get('/login',function(req, res) {
  if(!req.session.value){
  res.render('login');
  }else{
    res.render('schedule');
  }
});

app.get('/schedule', function(req, res){
  if(!req.session.value){
    res.redirect(302, '/login');
  }else{
  res.render('schedule');
  }
})

app.get('/getSchedule', function(req, res){
  var day = req.query.day;
  connection.query('SELECT * FROM tbl_events WHERE event_day = ? ORDER BY event_start ASC', [day], function(err, result, fields){
    if(err){
      throw err;
    }
    res.json(result);
    })
  })


app.get('/addEvent', function(req, res){
  if(!req.session.value){
    res.render('login');
  }else{
  res.render('addEvent');
  }
})

app.get('/logout', function(req, res){
  if(req.session.value)
    req.session.destroy((err) => {
      if(err)
        throw err;
      else
        console.log("Successfully logged out!");
    });
    else
      console.log("Not logged in!");
      res.redirect(302, '/login');
})

app.get('/editEvent/:id', function(req, res){
  const rowId = req.params.id;
  var event = {};
  if (req.session.user){
    connection.query('SELECT * FROM tbl_events WHERE event_id = \'' + rowId + '\'', function(err, rows, fields){
      if(err){
        throw err;
      }
      event = {
          event_id: req.params.id,
          event_day: rows[0].event_day,
          event_event: rows[0].event_event,
          event_start: rows[0].event_start,
          event_end: rows[0].event_end,
          event_location: rows[0].event_location,
          event_phone: rows[0].event_phone,
          event_info: rows[0].event_info,
          event_url: rows[0].event_url
      };
      res.render('updateEvent', {creating: false, record: event});
      
    })

  }else{
    res.redirect(302, '/login');
  }

})

app.get(`/deleteEvent/:id`, function(req, res){
  const rowId = req.params.id;
  if(req.params.id){
    connection.query('DELETE FROM tbl_events WHERE event_id = ?', [rowId], function(err, rows, fields){
      if(err){
        throw err;
      }else{
        res.json({status: 'success'});
      }
    })
  }else{
    res.sendStatus(404);
  }
})

app.post(`/editEventEntry/:id`, function(req, res){
  var id = req.params.id;
  var data = JSON.parse(JSON.stringify(req.body));
  console.log(data);
  console.log(id);
  if(req.params.id){
    connection.query('UPDATE tbl_events SET event_day = ?, event_event = ?, event_start = ?, event_end = ?, event_location = ?, event_phone = ?, event_info = ?, event_url = ? WHERE event_id = ?', [data.day, data.event, data.start, data.end, data.location, data.phone, data.info, data.url, id], function(err, rows, fields){
      if(err){
        throw err;
      }else{
        console.log("Row " + id + " updated!");
        res.redirect(302, '/schedule');
      }

    })
  }else{
    res.sendStatus(422);
  }
})

app.post('/sendLoginDetails', function(req, res){
  console.log("Validating Credentials");
  var uname = req.body.username;
  var password = req.body.password;
  connection.query("SELECT * FROM tbl_accounts", function(err, rows){
    if(err){
      throw err;
    }if(uname === "" && password === ""){
      console.log("No entries");
    }if(rows.length >= 1){
      if(bcrypt.compareSync(password, rows[0].acc_password)){
        req.session.user = uname;
        console.log("Successful Login")
        req.session.value = 1;
        res.json({status: 'success'});
      }else{
        console.log("Invalid Credentials");
        res.json({status: 'fail'});
      }
    }else{
      res.json({status:'fail'});
    }
  });
});

app.post('/addingEvent', function(req, res){
  const rowsToBeInserted = {
    event_day: req.body.day,
    event_event: req.body.event,
    event_start: req.body.start,
    event_end: req.body.end,
    event_location: req.body.location,
    event_phone: req.body.phone,
    event_info: req.body.info,
    event_url: req.body.url
  };
  connection.query('INSERT INTO tbl_events SET ?', rowsToBeInserted, function(err, rows){
    if(err){
      throw err;
    }
    res.redirect('/schedule');
  })
})
// middle ware to serve static files
app.use('/client', express.static(__dirname + '/client'));


// function to return the 404 message and error to client
app.get('*', function(req, res) {
  // add details
  res.sendStatus(404);
});
